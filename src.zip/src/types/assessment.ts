export interface Assessment {
    id: number;
    patient_id: number;

    qmg_score: number;
    mgc_score: number;
    cfq_total: number;

    treatment_change: number;
    infection_event: number;

    observation_date: string;
}
