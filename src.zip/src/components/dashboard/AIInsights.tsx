import {
  Card,
  CardContent,
  Divider,
  List,
  ListItem,
  ListItemAvatar,
  Avatar,
  ListItemText,
  Typography,
} from "@mui/material";

import WarningRoundedIcon from "@mui/icons-material/WarningRounded";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";
import MedicalServicesRoundedIcon from "@mui/icons-material/MedicalServicesRounded";
import PsychologyRoundedIcon from "@mui/icons-material/PsychologyRounded";

const insights = [
  {
    icon: <WarningRoundedIcon />,
    color: "#EF4444",
    title: "High Risk Patients",
    value: "3 patients require immediate attention",
  },
  {
    icon: <TrendingUpRoundedIcon />,
    color: "#2563EB",
    title: "Weekly Trend",
    value: "Risk increased by 12%",
  },
  {
    icon: <MedicalServicesRoundedIcon />,
    color: "#10B981",
    title: "Recommendation",
    value: "2 interventions suggested",
  },
  {
    icon: <PsychologyRoundedIcon />,
    color: "#7C3AED",
    title: "Model Accuracy",
    value: "91.2%",
  },
];

export default function AIInsights() {
  return (
    <Card
      elevation={0}
      sx={{
        borderRadius: 4,
        border: "1px solid #E5E7EB",
        boxShadow: "0 8px 24px rgba(15,23,42,.08)",
      }}
    >
      <CardContent>
        <Typography
          variant="h6"
          fontWeight={700}
          mb={2}
        >
          AI Clinical Insights
        </Typography>

        <List disablePadding>
          {insights.map((item, index) => (
            <div key={index}>
              <ListItem disableGutters>
                <ListItemAvatar>
                  <Avatar
                    sx={{
                      bgcolor: `${item.color}20`,
                      color: item.color,
                    }}
                  >
                    {item.icon}
                  </Avatar>
                </ListItemAvatar>

                <ListItemText
                  primary={item.title}
                  secondary={item.value}
                />
              </ListItem>

              {index !== insights.length - 1 && (
                <Divider />
              )}
            </div>
          ))}
        </List>
      </CardContent>
    </Card>
  );
}