import {
  Avatar,
  Box,
  Button,
  Card,
  CardContent,
  Chip,
  Stack,
  Typography,
} from "@mui/material";

import VisibilityRoundedIcon from "@mui/icons-material/VisibilityRounded";
import PsychologyRoundedIcon from "@mui/icons-material/PsychologyRounded";

const predictions = [
  {
    id: "MG001",
    name: "John Smith",
    probability: "84%",
    risk: "High",
    color: "error",
    time: "10 mins ago",
  },
  {
    id: "MG002",
    name: "Emma Wilson",
    probability: "32%",
    risk: "Medium",
    color: "warning",
    time: "35 mins ago",
  },
  {
    id: "MG003",
    name: "David Lee",
    probability: "12%",
    risk: "Low",
    color: "success",
    time: "1 hour ago",
  },
];

export default function RecentPredictions() {
  return (
    <Card
      elevation={0}
      sx={{
        borderRadius: 4,
        border: "1px solid #E5E7EB",
        boxShadow: "0 8px 24px rgba(15,23,42,.08)",
      }}
    >
      <CardContent>
        <Stack
          direction="row"
          justifyContent="space-between"
          alignItems="center"
          mb={3}
        >
          <Stack direction="row" spacing={1} alignItems="center">
            <PsychologyRoundedIcon color="primary" />
            <Typography variant="h6" fontWeight={700}>
              Recent Predictions
            </Typography>
          </Stack>

          <Button size="small">View All</Button>
        </Stack>

        <Stack spacing={2}>
          {predictions.map((patient) => (
            <Box
              key={patient.id}
              sx={{
                p: 2,
                borderRadius: 3,
                border: "1px solid #E5E7EB",
                transition: ".25s",

                "&:hover": {
                  bgcolor: "#F8FAFC",
                },
              }}
            >
              <Stack
                direction="row"
                justifyContent="space-between"
                alignItems="center"
              >
                <Stack direction="row" spacing={2} alignItems="center">
                  <Avatar
                    sx={{
                      bgcolor: "#2563EB",
                    }}
                  >
                    {patient.name[0]}
                  </Avatar>

                  <Box>
                    <Typography fontWeight={600}>
                      {patient.name}
                    </Typography>

                    <Typography
                      variant="body2"
                      color="text.secondary"
                    >
                      {patient.id}
                    </Typography>
                  </Box>
                </Stack>

                <Box textAlign="center">
                  <Typography
                    fontWeight={700}
                    color="primary"
                  >
                    {patient.probability}
                  </Typography>

                  <Typography
                    variant="caption"
                    color="text.secondary"
                  >
                    Probability
                  </Typography>
                </Box>

                <Chip
                  label={patient.risk}
                  color={patient.color as any}
                  sx={{
                    width: 90,
                    fontWeight: 600,
                  }}
                />

                <Typography
                  color="text.secondary"
                  fontSize={13}
                >
                  {patient.time}
                </Typography>

                <Button
                  size="small"
                  variant="outlined"
                  startIcon={<VisibilityRoundedIcon />}
                >
                  View
                </Button>
              </Stack>
            </Box>
          ))}
        </Stack>
      </CardContent>
    </Card>
  );
}