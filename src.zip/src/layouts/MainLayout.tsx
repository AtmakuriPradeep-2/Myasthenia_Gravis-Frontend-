import { Box } from "@mui/material";

import Sidebar from "../components/layout/Sidebar";
import Navbar from "../components/layout/Navbar";

export default function MainLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <Box sx={{ display: "flex" }}>
      <Sidebar />

      <Box
        sx={{
          flex: 1,
          background: "#F4F7FC",
          minHeight: "100vh",
        }}
      >
        <Navbar />

        <Box p={3}>{children}</Box>
      </Box>
    </Box>
  );
}