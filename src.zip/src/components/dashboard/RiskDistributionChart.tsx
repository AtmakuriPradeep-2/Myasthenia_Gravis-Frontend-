// RiskDistributionChart.tsx
import { Card, CardContent, Typography, Box, Stack } from "@mui/material";
import DonutLargeRoundedIcon from "@mui/icons-material/DonutLargeRounded";

import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from "recharts";

const data = [
  { name: "Low", value: 68 },
  { name: "Medium", value: 20 },
  { name: "High", value: 12 },
];

const COLORS: Record<string, string> = {
  Low: "#10B981",
  Medium: "#F59E0B",
  High: "#EF4444",
};

function CustomTooltip({ active, payload }: any) {
  if (!active || !payload?.length) return null;
  const entry = payload[0];
  return (
    <Box
      sx={{
        bgcolor: "#0F172A",
        color: "#fff",
        px: 1.5,
        py: 1,
        borderRadius: 2,
        boxShadow: "0 8px 20px rgba(0,0,0,.25)",
      }}
    >
      <Typography variant="subtitle2" fontWeight={700}>
        {entry.name}: {entry.value}%
      </Typography>
    </Box>
  );
}

export default function RiskDistributionChart() {
  const total = data.reduce((sum, d) => sum + d.value, 0);

  return (
    <Card
      elevation={0}
      sx={{
        height: 380,
        borderRadius: 4,
        border: "1px solid #E5E7EB",
        boxShadow: "0 8px 24px rgba(15,23,42,.06)",
        transition: "box-shadow .25s ease, transform .25s ease",
        "&:hover": {
          boxShadow: "0 12px 32px rgba(15,23,42,.12)",
          transform: "translateY(-2px)",
        },
      }}
    >
      <CardContent sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
        <Box display="flex" alignItems="center" gap={1} mb={2}>
          <Box
            sx={{
              width: 36,
              height: 36,
              borderRadius: 2,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              bgcolor: "rgba(124,58,237,0.1)",
            }}
          >
            <DonutLargeRoundedIcon sx={{ color: "#7C3AED", fontSize: 20 }} />
          </Box>
          <Typography fontWeight={700} variant="h6" sx={{ fontSize: "1.05rem" }}>
            Risk Distribution
          </Typography>
        </Box>

        <Box sx={{ position: "relative", flex: 1 }}>
          <ResponsiveContainer width="100%" height="100%">
            <PieChart>
              <Pie
                data={data}
                dataKey="value"
                nameKey="name"
                innerRadius={70}
                outerRadius={105}
                paddingAngle={3}
                cornerRadius={6}
                stroke="none"
              >
                {data.map((entry) => (
                  <Cell key={entry.name} fill={COLORS[entry.name]} />
                ))}
              </Pie>
              <Tooltip content={<CustomTooltip />} />
            </PieChart>
          </ResponsiveContainer>

          {/* Center label */}
          <Box
            sx={{
              position: "absolute",
              top: "42%",
              left: "50%",
              transform: "translate(-50%, -50%)",
              textAlign: "center",
              pointerEvents: "none",
            }}
          >
            <Typography variant="h5" fontWeight={800} color="#0F172A">
              {total}%
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Total
            </Typography>
          </Box>
        </Box>

        <Stack direction="row" spacing={2.5} justifyContent="center" mt={1}>
          {data.map((entry) => (
            <Box key={entry.name} display="flex" alignItems="center" gap={0.75}>
              <Box
                sx={{
                  width: 10,
                  height: 10,
                  borderRadius: "3px",
                  bgcolor: COLORS[entry.name],
                }}
              />
              <Typography variant="body2" fontWeight={600} color="text.secondary">
                {entry.name}
              </Typography>
            </Box>
          ))}
        </Stack>
      </CardContent>
    </Card>
  );
}