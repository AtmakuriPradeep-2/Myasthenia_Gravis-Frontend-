import {
  AppBar,
  Toolbar,
  Typography,
  Avatar,
  Box,
  Button,
} from "@mui/material";

import PsychologyIcon from "@mui/icons-material/Psychology";

export default function Topbar() {
  return (
    <AppBar
      position="static"
      elevation={0}
      sx={{
        bgcolor: "#111827",
        borderBottom:
          "1px solid #1e293b",
      }}
    >
      <Toolbar>
        <Typography
          variant="h4"
          fontWeight="bold"
          sx={{ flexGrow: 1 }}
        >
          Dashboard Overview
        </Typography>

        <Button
          variant="contained"
          startIcon={<PsychologyIcon />}
        >
          Run AI Prediction
        </Button>

        <Box
          display="flex"
          alignItems="center"
          ml={3}
        >
          <Avatar>P</Avatar>

          <Box ml={2}>
            <Typography>
              Pradeep
            </Typography>

            <Typography
              variant="body2"
            >
              Clinician
            </Typography>
          </Box>
        </Box>
      </Toolbar>
    </AppBar>
  );
}