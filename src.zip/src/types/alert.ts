export interface Alert {

    id:number;

    patient_id:number;

    prediction_id:number;

    probability:number;

    severity:string;

    status:string;

    review_notes:string | null;

    reviewed_by:number | null;

    reviewed_at:string | null;

    created_at:string;

    closed_at:string | null;
}