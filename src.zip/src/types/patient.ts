export interface Patient {
    id: number;
    patient_code: string;
    age: number;
    sex: string;
    mgfa_class: string;
}

export interface CreatePatientRequest {
    patient_code: string;
    age: number;
    sex: string;
    mgfa_class: string;
}