import Grid from "@mui/material/Grid";

import PeopleIcon from "@mui/icons-material/People";
import NotificationsIcon from "@mui/icons-material/Notifications";
import MedicalServicesIcon from "@mui/icons-material/MedicalServices";
import PsychologyIcon from "@mui/icons-material/Psychology";

import StatisticsCard from "./StatisticsCard";

interface Props {
  summary: any;
}

export default function StatisticsCards({
  summary,
}: Props) {
  return (
    <Grid container spacing={3} mb={4}>

      <Grid item xs={12} md={3}>
        <StatisticsCard
          title="Total Patients"
          value={summary.total_patients}
          icon={<PeopleIcon />}
          color="#2563EB"
          growth="+12%"
        />
      </Grid>

      <Grid item xs={12} md={3}>
        <StatisticsCard
          title="Alerts"
          value={summary.total_alerts}
          icon={<NotificationsIcon />}
          color="#EF4444"
          growth="+6%"
        />
      </Grid>

      <Grid item xs={12} md={3}>
        <StatisticsCard
          title="Interventions"
          value={summary.total_interventions}
          icon={<MedicalServicesIcon />}
          color="#10B981"
          growth="+3%"
        />
      </Grid>

      <Grid item xs={12} md={3}>
        <StatisticsCard
          title="High Risk"
          value={summary.high_risk_patients}
          icon={<PsychologyIcon />}
          color="#F59E0B"
          growth="+4%"
        />
      </Grid>

    </Grid>
  );
}