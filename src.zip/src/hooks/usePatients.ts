import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import patientService from "../services/patient.service";
import type { CreatePatient } from "../types/patient";

export function usePatients() {
  return useQuery({
    queryKey: ["patients"],
    queryFn: () => patientService.getPatients(),
  });
}

export function useCreatePatient() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: CreatePatient) =>
      patientService.createPatient(data),

    onSuccess: () => {
      queryClient.invalidateQueries({
        queryKey: ["patients"],
      });
    },
  });
}