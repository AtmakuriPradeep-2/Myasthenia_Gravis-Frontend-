import {
  Card,
  CardContent,
  Typography,
  Box,
} from "@mui/material";

interface Props {
  title: string;
  value: number | string;
  icon?: React.ReactNode;
}

export default function StatCard({
  title,
  value,
  icon,
}: Props) {
  return (
    <Card elevation={2}>
      <CardContent>
        <Box
          display="flex"
          justifyContent="space-between"
          alignItems="center"
        >
          <Box>
            <Typography
              color="text.secondary"
            >
              {title}
            </Typography>

            <Typography
              variant="h4"
              fontWeight={700}
            >
              {value}
            </Typography>
          </Box>

          {icon}
        </Box>
      </CardContent>
    </Card>
  );
}