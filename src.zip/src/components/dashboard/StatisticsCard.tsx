import { Box, Typography } from "@mui/material";

import PeopleIcon from "@mui/icons-material/People";
import WarningAmberRoundedIcon from "@mui/icons-material/WarningAmberRounded";
import NotificationsActiveRoundedIcon from "@mui/icons-material/NotificationsActiveRounded";
import MedicalServicesRoundedIcon from "@mui/icons-material/MedicalServicesRounded";
import PsychologyRoundedIcon from "@mui/icons-material/PsychologyRounded";

import StatCard from "./StatCard";

interface Props {
  summary: {
    total_patients: number;
    total_alerts: number;
    total_interventions: number;
    high_risk_patients: number;
  };
}

const CARDS_CONFIG = [
  {
    title: "Patients",
    subtitle: "Registered",
    color: "#2563EB",
    icon: <PeopleIcon />,
    key: "total_patients" as const,
  },
  {
    title: "High Risk",
    subtitle: "Need Attention",
    color: "#EF4444",
    icon: <WarningAmberRoundedIcon />,
    key: "high_risk_patients" as const,
  },
  {
    title: "Alerts",
    subtitle: "Open Alerts",
    color: "#F59E0B",
    icon: <NotificationsActiveRoundedIcon />,
    key: "total_alerts" as const,
  },
  {
    title: "Interventions",
    subtitle: "Completed",
    color: "#10B981",
    icon: <MedicalServicesRoundedIcon />,
    key: "total_interventions" as const,
  },
];

export default function StatisticsCards({ summary }: Props) {
  return (
    <Box sx={{ mb: 4 }}>
      <Typography
        variant="subtitle2"
        sx={{
          color: "text.secondary",
          fontWeight: 600,
          letterSpacing: 0.4,
          textTransform: "uppercase",
          mb: 1.5,
        }}
      >
        Overview
      </Typography>

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "1fr",
            sm: "repeat(2, 1fr)",
            md: "repeat(3, 1fr)",
            lg: "repeat(5, 1fr)",
          },
          gap: 2.5,
        }}
      >
        {CARDS_CONFIG.map((card) => (
          <StatCard
            key={card.key}
            title={card.title}
            value={summary[card.key]}
            subtitle={card.subtitle}
            color={card.color}
            icon={card.icon}
          />
        ))}

        <StatCard
          title="Accuracy"
          value="91.2%"
          subtitle="AI Model"
          color="#7C3AED"
          icon={<PsychologyRoundedIcon />}
        />
      </Box>
    </Box>
  );
}