export interface Intervention {

    id:number;

    patient_id:number;

    intervention_type:string;

    description:string;

    created_at:string;
}