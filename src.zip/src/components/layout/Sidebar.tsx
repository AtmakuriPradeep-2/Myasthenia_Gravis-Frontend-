import {
  Dashboard,
  People,
  Assessment,
  Psychology,
  Notifications,
  MedicalServices,
  Analytics,
  Person,
  Logout,
} from "@mui/icons-material";

import {
  Box,
  Divider,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Typography,
} from "@mui/material";

import { NavLink } from "react-router-dom";

const menu = [
  { title: "Dashboard", icon: <Dashboard />, path: "/" },
  { title: "Patients", icon: <People />, path: "/patients" },
  { title: "Assessments", icon: <Assessment />, path: "/assessments" },
  { title: "Predictions", icon: <Psychology />, path: "/predictions" },
  { title: "Alerts", icon: <Notifications />, path: "/alerts" },
  {
    title: "Interventions",
    icon: <MedicalServices />,
    path: "/interventions",
  },
  { title: "Analytics", icon: <Analytics />, path: "/analytics" },
  { title: "Profile", icon: <Person />, path: "/profile" },
];

export default function Sidebar() {
  return (
    <Box
      sx={{
        width: 260,
        bgcolor: "#111827",
        color: "#fff",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Typography
        variant="h5"
        sx={{
          p: 3,
          fontWeight: 700,
          textAlign: "center",
        }}
      >
        MG AI
      </Typography>

      <Divider sx={{ bgcolor: "#374151" }} />

      <List sx={{ flexGrow: 1 }}>
        {menu.map((item) => (
          <ListItemButton
            key={item.title}
            component={NavLink}
            to={item.path}
            sx={{
              color: "#fff",
              "&.active": {
                bgcolor: "#2563EB",
              },
            }}
          >
            <ListItemIcon sx={{ color: "#fff" }}>
              {item.icon}
            </ListItemIcon>

            <ListItemText primary={item.title} />
          </ListItemButton>
        ))}
      </List>

      <Divider sx={{ bgcolor: "#374151" }} />

      <List>
        <ListItemButton>
          <ListItemIcon sx={{ color: "#fff" }}>
            <Logout />
          </ListItemIcon>

          <ListItemText primary="Logout" />
        </ListItemButton>
      </List>
    </Box>
  );
}