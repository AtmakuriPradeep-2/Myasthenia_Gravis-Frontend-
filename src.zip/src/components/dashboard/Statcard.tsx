import {
  Card,
  Typography,
  Avatar,
  Stack,
  Box,
} from "@mui/material";

interface Props {
  title: string;
  value: string | number;
  subtitle: string;
  color: string;
  icon: React.ReactNode;
}

export default function StatCard({
  title,
  value,
  subtitle,
  color,
  icon,
}: Props) {
  return (
    <Card
      elevation={0}
      sx={{
        p: 3,
        borderRadius: 4,
        border: "1px solid #E5E7EB",

        boxShadow:
          "0 8px 20px rgba(15,23,42,.06)",

        transition: ".25s",

        "&:hover": {
          transform: "translateY(-5px)",
          boxShadow:
            "0 15px 35px rgba(15,23,42,.12)",
        },
      }}
    >
      <Stack
        direction="row"
        justifyContent="space-between"
      >
        <Box>
          <Typography
            color="text.secondary"
            fontSize={14}
          >
            {title}
          </Typography>

          <Typography
            mt={1}
            fontWeight={700}
            fontSize={38}
          >
            {value}
          </Typography>

          <Typography
            mt={1}
            color="text.secondary"
            fontSize={13}
          >
            {subtitle}
          </Typography>
        </Box>

        <Avatar
          sx={{
            bgcolor: `${color}20`,
            color,
            width: 58,
            height: 58,
          }}
        >
          {icon}
        </Avatar>
      </Stack>
    </Card>
  );
}