import api from "../api/axios";
import type { Patient, CreatePatient } from "../types/patient";

class PatientService {
  async getPatients() {
    const response = await api.get<Patient[]>("/patients");
    return response.data;
  }

  async createPatient(data: CreatePatient) {
    const response = await api.post<Patient>("/patients", data);
    return response.data;
  }
}

export default new PatientService();