import {
  AppBar,
  Toolbar,
  Typography,
  Box,
  Avatar,
  IconButton,
  Badge,
  Paper,
} from "@mui/material";

import NotificationsNoneIcon from "@mui/icons-material/NotificationsNone";
import CalendarTodayIcon from "@mui/icons-material/CalendarToday";

import dayjs from "dayjs";

import { useAuth } from "../../contexts/AuthContext";

export default function Navbar() {
  const { user } = useAuth();

  return (
    <AppBar
      position="sticky"
      elevation={1}
      color="inherit"
      sx={{
        bgcolor: "#FFFFFF",
        borderBottom: "1px solid #E5E7EB",
      }}
    >
      <Toolbar
        sx={{
          minHeight: 75,
          display: "flex",
          justifyContent: "space-between",
        }}
      >
        {/* Left Side */}
        <Box>
          <Typography
            variant="h5"
            fontWeight={700}
            color="primary"
          >
            MG AI Remote Monitoring System
          </Typography>

          <Box
            display="flex"
            alignItems="center"
            mt={0.5}
          >
            <CalendarTodayIcon
              sx={{
                fontSize: 16,
                color: "text.secondary",
                mr: 1,
              }}
            />

            <Typography
              variant="body2"
              color="text.secondary"
            >
              {dayjs().format("dddd, DD MMMM YYYY")}
            </Typography>
          </Box>
        </Box>

        {/* Right Side */}
        <Box
          display="flex"
          alignItems="center"
          gap={3}
        >
          <IconButton>
            <Badge
              badgeContent={0}
              color="error"
            >
              <NotificationsNoneIcon />
            </Badge>
          </IconButton>

          <Paper
            elevation={0}
            sx={{
              display: "flex",
              alignItems: "center",
              gap: 2,
              px: 2,
              py: 1,
              borderRadius: 3,
              bgcolor: "#F8FAFC",
            }}
          >
            <Box textAlign="right">
              <Typography
                fontWeight={600}
                fontSize={15}
              >
                {user?.full_name ?? "Guest User"}
              </Typography>

              <Typography
                variant="body2"
                color="text.secondary"
              >
                {user?.role ?? "Clinician"}
              </Typography>
            </Box>

            <Avatar
              sx={{
                bgcolor: "#2563EB",
                width: 44,
                height: 44,
                fontWeight: 700,
              }}
            >
              {user?.full_name
                ? user.full_name.charAt(0).toUpperCase()
                : "U"}
            </Avatar>
          </Paper>
        </Box>
      </Toolbar>
    </AppBar>
  );
}