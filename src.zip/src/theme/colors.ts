// src/theme/colors.ts

export const colors = {
  primary: {
    main: "#2563EB",
    light: "#60A5FA",
    dark: "#1E40AF",
    contrastText: "#FFFFFF",
    gradient: "linear-gradient(135deg,#2563EB,#1E40AF)",
  },

  secondary: {
    main: "#06B6D4",
    light: "#67E8F9",
    dark: "#0891B2",
    contrastText: "#FFFFFF",
  },

  success: {
    main: "#10B981",
    light: "#D1FAE5",
    dark: "#047857",
  },

  warning: {
    main: "#F59E0B",
    light: "#FEF3C7",
    dark: "#B45309",
  },

  error: {
    main: "#EF4444",
    light: "#FEE2E2",
    dark: "#B91C1C",
  },

  info: {
    main: "#3B82F6",
    light: "#DBEAFE",
    dark: "#1D4ED8",
  },

  background: {
    default: "#F5F7FB",
    paper: "#FFFFFF",
    sidebar: "#0F172A",
    navbar: "#FFFFFF",
    card: "#FFFFFF",
  },

  text: {
    primary: "#1E293B",
    secondary: "#64748B",
    disabled: "#94A3B8",
    white: "#FFFFFF",
  },

  border: {
    light: "#E2E8F0",
    medium: "#CBD5E1",
  },

  shadow: {
    sm: "0 2px 8px rgba(15,23,42,0.06)",
    md: "0 10px 30px rgba(15,23,42,0.08)",
    lg: "0 20px 45px rgba(15,23,42,0.15)",
  },

  chart: {
    blue: "#2563EB",
    green: "#10B981",
    orange: "#F59E0B",
    red: "#EF4444",
    purple: "#7C3AED",
  },

  status: {
    low: "#10B981",
    medium: "#F59E0B",
    high: "#EF4444",
  },
};