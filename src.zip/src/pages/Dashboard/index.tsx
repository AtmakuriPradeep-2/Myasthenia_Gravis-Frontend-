import {
  Alert,
  Box,
  CircularProgress,
  Grid,
} from "@mui/material";

import DashboardHeader from "../../components/dashboard/DashboardHeader";
import StatisticsCards from "../../components/dashboard/StatisticsCard";

import RiskTrendChart from "../../components/dashboard/RiskTrendChart";
import RiskDistributionChart from "../../components/dashboard/RiskDistributionChart";
import RecentPredictions from "../../components/dashboard/RecentPredictions";
import AIInsights from "../../components/dashboard/AIInsights";

import { useDashboardSummary } from "../../hooks/useDashboard";

export default function Dashboard() {
  const {
    data,
    isLoading,
    isError,
    refetch,
  } = useDashboardSummary();

  if (isLoading) {
    return (
      <Box
        display="flex"
        justifyContent="center"
        alignItems="center"
        minHeight="70vh"
      >
        <CircularProgress size={60} />
      </Box>
    );
  }

  if (isError || !data) {
    return (
      <Alert severity="error">
        Failed to load dashboard data.
      </Alert>
    );
  }

 return (
  <Box
    sx={{
      display: "flex",
      flexDirection: "column",
      gap: 4,
    }}
  >
    <DashboardHeader onRefresh={refetch} />

    <StatisticsCards
      summary={{
        total_patients: data.total_patients,
        total_alerts: data.total_alerts,
        total_interventions: data.total_interventions,
        high_risk_patients: data.open_alerts,
      }}
    />

    <Grid container spacing={3}>
      <Grid item xs={12} lg={8}>
        <RiskTrendChart />
      </Grid>

      <Grid item xs={12} lg={4}>
        <RiskDistributionChart />
      </Grid>

      <Grid item xs={12} lg={8}>
        <RecentPredictions />
      </Grid>

      <Grid item xs={12} lg={4}>
        <AIInsights />
      </Grid>
    </Grid>
  </Box>
);
}