import { useQuery } from "@tanstack/react-query";
import dashboardService from "../services/dashboard.service";

export const useDashboardSummary = () =>
  useQuery({
    queryKey: ["dashboard-summary"],
    queryFn: () => dashboardService.getSummary(),
  });

export const usePredictionTrends = () =>
  useQuery({
    queryKey: ["prediction-trends"],
    queryFn: () => dashboardService.getPredictionTrends(),
  });

export const useRiskDistribution = () =>
  useQuery({
    queryKey: ["risk-distribution"],
    queryFn: () => dashboardService.getRiskDistribution(),
  });

export const usePatientStatistics = () =>
  useQuery({
    queryKey: ["patient-statistics"],
    queryFn: () => dashboardService.getPatientStatistics(),
  });

export const useAlertStatistics = () =>
  useQuery({
    queryKey: ["alert-statistics"],
    queryFn: () => dashboardService.getAlertStatistics(),
  });

export const useInterventionStatistics = () =>
  useQuery({
    queryKey: ["intervention-statistics"],
    queryFn: () => dashboardService.getInterventionStatistics(),
  });