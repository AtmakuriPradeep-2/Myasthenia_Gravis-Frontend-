import { useState } from "react";
import {
  Paper,
  Grid,
  TextField,
  MenuItem,
  Button,
  Typography,
} from "@mui/material";
import toast from "react-hot-toast";

import { useCreatePatient } from "../../hooks/usePatients";

export default function PatientForm() {
  const { mutateAsync, isPending } = useCreatePatient();

  const [form, setForm] = useState({
    patient_code: "",
    age: "",
    sex: "Male",
    mgfa_class: "I",
  });

  async function handleSubmit(
    e: React.FormEvent
  ) {
    e.preventDefault();

    try {
      await mutateAsync({
        patient_code: form.patient_code,
        age: Number(form.age),
        sex: form.sex,
        mgfa_class: form.mgfa_class,
      });

      toast.success("Patient created successfully");

      setForm({
        patient_code: "",
        age: "",
        sex: "Male",
        mgfa_class: "I",
      });
    } catch {
      toast.error("Unable to create patient");
    }
  }

  return (
    <Paper sx={{ p: 3 }}>
      <Typography
        variant="h6"
        mb={3}
      >
        Register Patient
      </Typography>

      <form onSubmit={handleSubmit}>
        <Grid container spacing={2}>
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              label="Patient Code"
              value={form.patient_code}
              onChange={(e) =>
                setForm({
                  ...form,
                  patient_code:
                    e.target.value,
                })
              }
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              type="number"
              label="Age"
              value={form.age}
              onChange={(e) =>
                setForm({
                  ...form,
                  age: e.target.value,
                })
              }
            />
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              select
              fullWidth
              label="Sex"
              value={form.sex}
              onChange={(e) =>
                setForm({
                  ...form,
                  sex: e.target.value,
                })
              }
            >
              <MenuItem value="Male">
                Male
              </MenuItem>

              <MenuItem value="Female">
                Female
              </MenuItem>
            </TextField>
          </Grid>

          <Grid item xs={12} md={6}>
            <TextField
              select
              fullWidth
              label="MGFA Class"
              value={form.mgfa_class}
              onChange={(e) =>
                setForm({
                  ...form,
                  mgfa_class:
                    e.target.value,
                })
              }
            >
              <MenuItem value="I">I</MenuItem>
              <MenuItem value="II">II</MenuItem>
              <MenuItem value="III">III</MenuItem>
              <MenuItem value="IV">IV</MenuItem>
              <MenuItem value="V">V</MenuItem>
            </TextField>
          </Grid>

          <Grid item xs={12}>
            <Button
              variant="contained"
              type="submit"
              disabled={isPending}
            >
              {isPending
                ? "Saving..."
                : "Create Patient"}
            </Button>
          </Grid>
        </Grid>
      </form>
    </Paper>
  );
}