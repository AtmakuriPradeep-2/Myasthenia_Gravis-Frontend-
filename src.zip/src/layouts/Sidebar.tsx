import {
  Box,
  Divider,
  Drawer,
  List,
  ListItemButton,
  ListItemIcon,
  ListItemText,
  Toolbar,
  Typography,
} from "@mui/material";

import {
  Dashboard,
  People,
  Assessment,
  Psychology,
  Notifications,
  MedicalServices,
  Logout,
  MonitorHeart,
} from "@mui/icons-material";

import { NavLink, useLocation } from "react-router-dom";

const drawerWidth = 240;

const menus = [
  {
    text: "Dashboard",
    icon: <Dashboard />,
    path: "/dashboard",
  },
  {
    text: "Patients",
    icon: <People />,
    path: "/patients",
  },
  {
    text: "Assessments",
    icon: <Assessment />,
    path: "/assessments",
  },
  {
    text: "Predictions",
    icon: <Psychology />,
    path: "/predictions",
  },
  {
    text: "Alerts",
    icon: <Notifications />,
    path: "/alerts",
  },
  {
    text: "Interventions",
    icon: <MedicalServices />,
    path: "/interventions",
  },
];

export default function Sidebar() {
  const location = useLocation();

  return (
    <Drawer
      variant="permanent"
      sx={{
        width: drawerWidth,
        flexShrink: 0,

        "& .MuiDrawer-paper": {
          width: drawerWidth,
          bgcolor: "#0F172A",
          color: "#FFFFFF",
          borderRight: "none",
          display: "flex",
          flexDirection: "column",
        },
      }}
    >
      <Toolbar />

      {/* Logo */}
      <Box
        sx={{
          px: 3,
          py: 3,
          display: "flex",
          alignItems: "center",
          gap: 2,
        }}
      >
        <Box
          sx={{
            width: 48,
            height: 48,
            borderRadius: "14px",
            bgcolor: "#2563EB",
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <MonitorHeart sx={{ color: "white" }} />
        </Box>

        <Box>
          <Typography
            fontWeight={700}
            fontSize={20}
          >
            MG Monitor
          </Typography>

          <Typography
            fontSize={12}
            color="#94A3B8"
          >
            AI Healthcare
          </Typography>
        </Box>
      </Box>

      <Divider sx={{ borderColor: "#1E293B" }} />

      <List
        sx={{
          px: 2,
          py: 2,
          flexGrow: 1,
        }}
      >
        {menus.map((item) => {
          const active = location.pathname === item.path;

          return (
            <ListItemButton
              key={item.text}
              component={NavLink}
              to={item.path}
              sx={{
                borderRadius: 3,
                mb: 1,

                minHeight: 52,

                position: "relative",

                color: active
                  ? "#FFFFFF"
                  : "#CBD5E1",

                bgcolor: active
                  ? "#2563EB"
                  : "transparent",

                transition: ".25s",

                "&:hover": {
                  bgcolor: active
                    ? "#2563EB"
                    : "#1E293B",
                },

                "&::before": active
                  ? {
                      content: '""',
                      position: "absolute",
                      left: -8,
                      top: 10,
                      width: 4,
                      height: 32,
                      borderRadius: 2,
                      bgcolor: "#60A5FA",
                    }
                  : {},
              }}
            >
              <ListItemIcon
                sx={{
                  color: "inherit",
                  minWidth: 40,
                }}
              >
                {item.icon}
              </ListItemIcon>

              <ListItemText
                primary={item.text}
                primaryTypographyProps={{
                  fontSize: 15,
                  fontWeight: active ? 700 : 500,
                }}
              />
            </ListItemButton>
          );
        })}
      </List>

      <Divider sx={{ borderColor: "#1E293B" }} />

      {/* Footer */}
      <Box p={2}>
        <ListItemButton
          sx={{
            borderRadius: 3,
            color: "#FCA5A5",

            "&:hover": {
              bgcolor: "#7F1D1D",
            },
          }}
        >
          <ListItemIcon
            sx={{
              color: "#FCA5A5",
            }}
          >
            <Logout />
          </ListItemIcon>

          <ListItemText
            primary="Logout"
          />
        </ListItemButton>
      </Box>
    </Drawer>
  );
}