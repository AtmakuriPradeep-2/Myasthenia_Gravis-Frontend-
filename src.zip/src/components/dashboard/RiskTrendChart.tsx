// RiskTrendChart.tsx
import { Card, CardContent, Typography, Box, Chip } from "@mui/material";
import TrendingUpRoundedIcon from "@mui/icons-material/TrendingUpRounded";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";

const data = [
  { day: "Mon", risk: 15 },
  { day: "Tue", risk: 22 },
  { day: "Wed", risk: 18 },
  { day: "Thu", risk: 30 },
  { day: "Fri", risk: 25 },
  { day: "Sat", risk: 36 },
  { day: "Sun", risk: 28 },
];

const trendDelta = (
  ((data[data.length - 1].risk - data[0].risk) / data[0].risk) *
  100
).toFixed(0);

function CustomTooltip({ active, payload, label }: any) {
  if (!active || !payload?.length) return null;
  return (
    <Box
      sx={{
        bgcolor: "#0F172A",
        color: "#fff",
        px: 1.5,
        py: 1,
        borderRadius: 2,
        boxShadow: "0 8px 20px rgba(0,0,0,.25)",
      }}
    >
      <Typography variant="caption" sx={{ opacity: 0.7, display: "block" }}>
        {label}
      </Typography>
      <Typography variant="subtitle2" fontWeight={700}>
        Risk Score: {payload[0].value}
      </Typography>
    </Box>
  );
}

export default function RiskTrendChart() {
  const isUp = Number(trendDelta) >= 0;

  return (
    <Card
      elevation={0}
      sx={{
        height: 380,
        borderRadius: 4,
        border: "1px solid #E5E7EB",
        boxShadow: "0 8px 24px rgba(15,23,42,.06)",
        transition: "box-shadow .25s ease, transform .25s ease",
        "&:hover": {
          boxShadow: "0 12px 32px rgba(15,23,42,.12)",
          transform: "translateY(-2px)",
        },
      }}
    >
      <CardContent sx={{ height: "100%", display: "flex", flexDirection: "column" }}>
        <Box display="flex" alignItems="center" justifyContent="space-between" mb={2}>
          <Box display="flex" alignItems="center" gap={1}>
            <Box
              sx={{
                width: 36,
                height: 36,
                borderRadius: 2,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                bgcolor: "rgba(37,99,235,0.1)",
              }}
            >
              <TrendingUpRoundedIcon sx={{ color: "#2563EB", fontSize: 20 }} />
            </Box>
            <Typography fontWeight={700} variant="h6" sx={{ fontSize: "1.05rem" }}>
              7-Day Risk Trend
            </Typography>
          </Box>

          <Chip
            size="small"
            label={`${isUp ? "+" : ""}${trendDelta}%`}
            sx={{
              bgcolor: isUp ? "rgba(239,68,68,0.1)" : "rgba(16,185,129,0.1)",
              color: isUp ? "#EF4444" : "#10B981",
              fontWeight: 700,
              border: "none",
            }}
          />
        </Box>

        <ResponsiveContainer width="100%" height="100%">
          <AreaChart data={data} margin={{ top: 5, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="riskFill" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#2563EB" stopOpacity={0.35} />
                <stop offset="95%" stopColor="#2563EB" stopOpacity={0} />
              </linearGradient>
            </defs>

            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EEF2F6" />

            <XAxis
              dataKey="day"
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#94A3B8", fontSize: 12 }}
            />

            <YAxis
              axisLine={false}
              tickLine={false}
              tick={{ fill: "#94A3B8", fontSize: 12 }}
            />

            <Tooltip content={<CustomTooltip />} cursor={{ stroke: "#CBD5E1", strokeDasharray: 4 }} />

            <Area
              type="monotone"
              dataKey="risk"
              stroke="#2563EB"
              strokeWidth={3}
              fill="url(#riskFill)"
              dot={{ r: 4, fill: "#2563EB", strokeWidth: 2, stroke: "#fff" }}
              activeDot={{ r: 6 }}
            />
          </AreaChart>
        </ResponsiveContainer>
      </CardContent>
    </Card>
  );
}