import {
  Paper,
  Typography,
  Stack,
  Button,
  Box,
  Chip,
} from "@mui/material";

import RefreshIcon from "@mui/icons-material/Refresh";
import PsychologyIcon from "@mui/icons-material/Psychology";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import LocalHospitalIcon from "@mui/icons-material/LocalHospital";

interface Props {
  onRefresh: () => void;
}

export default function DashboardHeader({ onRefresh }: Props) {
  return (
    <Paper
      elevation={0}
      sx={{
        mb: 4,
        p: 4,
        borderRadius: 5,
        overflow: "hidden",

        background:
          "linear-gradient(135deg,#2563EB 0%,#1E40AF 100%)",

        color: "white",

        position: "relative",
      }}
    >
      <Stack
        direction={{
          xs: "column",
          lg: "row",
        }}
        justifyContent="space-between"
        spacing={4}
      >
        <Box>
          <Chip
            icon={<LocalHospitalIcon />}
            label="AI Healthcare Monitoring"
            sx={{
              bgcolor: "rgba(255,255,255,.18)",
              color: "white",
              mb: 2,
            }}
          />

          <Typography
            variant="h3"
            fontWeight={700}
          >
            AI Remote Monitoring Dashboard
          </Typography>

          <Typography
            mt={2}
            sx={{
              opacity: .9,
              maxWidth: 650,
            }}
          >
            Predicting Myasthenia Gravis Exacerbation
            using longitudinal patient monitoring
            and machine learning.
          </Typography>

          <Stack
            direction="row"
            spacing={2}
            mt={3}
          >
            <Chip
              icon={<TrendingUpIcon />}
              label="91.2% Accuracy"
              sx={{
                bgcolor: "rgba(255,255,255,.18)",
                color: "white",
              }}
            />

            <Chip
              label="Model Ready"
              color="success"
            />
          </Stack>
        </Box>

        <Stack
          direction={{
            xs: "row",
            md: "column",
          }}
          spacing={2}
          justifyContent="center"
        >
          <Button
            variant="contained"
            startIcon={<RefreshIcon />}
            onClick={onRefresh}
            sx={{
              bgcolor: "white",
              color: "#2563EB",
              minWidth: 180,
              height: 52,
              borderRadius: 3,
            }}
          >
            Refresh
          </Button>

          <Button
            variant="contained"
            startIcon={<PsychologyIcon />}
            sx={{
              bgcolor: "#0F172A",
              minWidth: 180,
              height: 52,
              borderRadius: 3,

              "&:hover": {
                bgcolor: "#111827",
              },
            }}
          >
            Run Prediction
          </Button>
        </Stack>
      </Stack>
    </Paper>
  );
}