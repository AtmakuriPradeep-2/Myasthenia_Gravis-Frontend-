export interface Prediction {

    id: number;

    patient_id: number;

    probability: number;

    threshold: number;

    risk_category: string;

    predicted_event: number;

    model_name: string;

    model_version: string;

    created_at: string;
}